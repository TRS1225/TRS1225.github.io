﻿
/*
* SNHU
* CS 499: Computer Science Capstone
* MOD 5 - Milestone Four - Enhancement Three: Databases
* Student Name : THOMAS SEIBERT
* The primary artifact enhancement in this project will be the incorporation of data mining.
* Specifically, I will add a method to calculate bid statistics, and add a menu option for users to do so.
* Furthermore, I will improve the functionality of this program to include user input validation,
more descriptive and accurate comments throughout the code, as well as re-naming methods and variables
in ways that are consistent and meaningful across the codebase.
* In order to validate user input in main menu, I will convert the switch statement to an if-else structure.
* This program allows users to load, print, search for, add, remove, and calculate bid data from a file via the
utilization of a Binary Search Tree class.
* Note: some parts of this program were provided to us by the University, and our (students) assignment
was to implement code under under the "FIXME" comments, and define other functions as well.
*/

//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : THOMAS SEIBERT
// Version     : 2.0
// Copyright   : Copyright � 2023 SNHU COCE
// Description : Lab 5-2 Binary Search Tree
//============================================================================

#include <iostream>
#include <time.h>
#include <iomanip>
#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// function to convert string to double
// this is a forward declaration
double strToDouble(string str, char ch);

// define a Bid structure object to contain bid information
struct Bid
{
	// declare variables
	string bidID; // unique identifier of a bid
	string bidTitle; // title of a bid
	string bidFund; // fund associated with a bid
	double bidAmount; // the amount of a bid

	// default constructor 
	Bid()
	{
		// assigns amount of a bid to 0 when a new structure object is created
		bidAmount = 0.0;
	}
};

// define a Node structure object which represents a node in the tree
struct Node
{
	// declare variables
	Bid bid; // instantiate Bid structure to contain information
	Node* left; // pointer to left child node of tree 
	Node* right; // pointer to right child node of tree

	// default constructor 
	Node()
	{
		left = nullptr; // init left pointer to nothing
		right = nullptr; // init right pointer to nothing
	}

	// constructor to init a Node with a Bid
	Node(Bid aBid) :
		// call the default constructor
		Node()
	{
		// assign the current bid to Bid object
		bid = aBid;
	}
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree
{
	// declare private methods
private:
	// declare pointer to point to the root node (starting point) of the tree
	Node* root;

	// methods
	void addNode(Node* node, Bid bid); // add new bid to tree starting at given node
	void inOrder(Node* node); // traverse tree in order (left root right) 
	void postOrder(Node* node); // traverse tree post order (left right root)
	void preOrder(Node* node); // traverse tree pre order (root left right)
	Node* removeNode(Node* node, string bidId); // remove node with specific bid ID from tree

	// declare public methods
public:
	BinarySearchTree(); // constructor for the class
	virtual ~BinarySearchTree(); // destructor for the class (called when object is deleted)
	void InOrder(); // init in order traversal of tree
	void PostOrder(); // init post order traversal of tree
	void PreOrder(); // init pre order traversal of tree
	void Insert(Bid bid); // insert a new bid into tree
	void Remove(string bidId); // remove a bid from tree using bid ID
	void incorporateDataMining(Node* node); // primary artifact enhancement
	Bid Search(string bidId); // search the tree for a bid using its ID and return it
	Node* getRootNode(); // method to get the root node to pass it to another method
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree()
{
	// FixMe (1): initialize housekeeping variables
	// init root (starting point) to nothing
	root = nullptr;
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree()
{
	// FixMe (2)
	// recurse from root deleting every node
	// loop will continue until there are no nodes left in the tree
	while (root != nullptr)
	{
		// call removeNode function
		// 2 parameters: current root node, bid ID stored in said node
		root = removeNode(root, root->bid.bidID);
	}
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder()
{
	// FixMe (3a): In order root
	// call inOrder function and pass root pointer as an argument 
	// "this" is a pointer that points to the current instance of the BST class
	this->inOrder(root);

}

/**
 * Traverse the tree in post-order
 */
void BinarySearchTree::PostOrder()
{
	// FixMe (4a): Post order root
	// call postOrder function and pass root pointer as an argument 
	// "this" is a pointer that points to the current instance of the BST class
	this->postOrder(root);
}

/**
 * Traverse the tree in pre-order
 */
void BinarySearchTree::PreOrder()
{
	// FixMe (5a): Pre order root
	// call preOrder function and pass root pointer as an argument 
	// "this" is a pointer that points to the current instance of the BST class
	this->preOrder(root);

}

/**
 * Insert a bid
 */
void BinarySearchTree::Insert(Bid bid)
{
	// FIXME (6a) Implement inserting a bid into the tree
	// check if the tree is empty (no nodes)
	if (root == nullptr)
	{
		// if so, create a new node in the tree passing bid into it
		root = new Node(bid);
	}

	// if the tree is not empty
	else
	{
		// then add the current root node and bid into it
		this->addNode(root, bid);
	}
}

/**
 * Remove a bid
 */
void BinarySearchTree::Remove(string bidId)
{
	// FIXME (7a) Implement removing a bid from the tree
	// pass current root and bid ID to removeNode function in order to remove a bid by its ID
	this->removeNode(root, bidId);
}

/**
 * Search for a bid
 */
Bid BinarySearchTree::Search(string bidId)
{
	// FIXME (8) Implement searching the tree for a bid
	// declare pointer and make it to point to the root of the tree
	// pointer will traverse the tree to search for bid
	Node* current = root;

	// loop will continue until there are no more nodes to check
	while (current != nullptr)
	{
		// if the bid ID of the current node matches the bid ID being searching for,
		// then the bid has been found
		if (current->bid.bidID == bidId)
		{
			// return the current bid
			return current->bid;
		}

		// if bid ID is less than the bid ID of the current node
		else if (bidId < current->bid.bidID)
		{
			// then traverse to the left child of current node
			current = current->left;
		}
		// if bid ID is greater than the bid ID of the current node
		else
		{
			// then traverse to the right child of current node
			current = current->right;
		}
	}

	// if a bid ID isn't found in tree, then
	// return a default bid object
	return Bid();
}

/**
 * Add a bid to some node (recursive)
 *
 * @param node Current node in tree
 * @param bid Bid to be added
 */
void BinarySearchTree::addNode(Node* node, Bid bid)
{
	// FIXME (6b) Implement inserting a bid into the tree
	// check if the bid ID of the bid to be added is less than the bid ID of the current node
	// to determine whether to place the new node in the left or right subtree of current node
	if (bid.bidID < node->bid.bidID)
	{
		// if there is no node in left position of the current node
		if (node->left == nullptr)
		{
			// place new bid here
			node->left = new Node(bid);
		}

		// if there is a bid in the left position already
		else
		{
			// continue searching left subtree to find the correct position for the new bid
			// using recursive call
			addNode(node->left, bid);
		}
	}

	// if the bid ID is greater than or equal to the current node's bid ID
	else
	{
		// if there is no node in right position of the current node
		if (node->right == nullptr)
		{
			// place new bid here
			node->right = new Node(bid);
		}

		// if there is a bid in the left position already
		else
		{
			// continue searching right subtree to find the correct position for the new bid
			// using recursive call
			addNode(node->right, bid);
		}
	}
}

/**
 * Traverse the tree in order (left root right)
 * parameter: pointer to the current node
 */
void BinarySearchTree::inOrder(Node* node)
{
	// FixMe (3b): Pre order root
	// check if the current node exists
	if (node != nullptr)
	{
		// if it does exist, traverse the left subtree of the current node
		// using recursive call
		inOrder(node->left);

		// then print bid ID, bid title, bid amount, each followed by a comma, then bid fund
		cout << node->bid.bidID << ", "
			<< node->bid.bidTitle << ", "
			<< node->bid.bidAmount << ", "
			<< node->bid.bidFund << endl;

		// then traverse the right subtree of the current node
		// using recursive call
		inOrder(node->right);
	}
}

/**
 * Traverse the tree post order (left right root)
 * parameter: pointer to the current node
 */
void BinarySearchTree::postOrder(Node* node)
{
	// FixMe (4b): Pre order root
	// check if the current node exists
	if (node != nullptr)
	{
		// if it does exist, traverse the left subtree of the current node
		// using recursive call
		postOrder(node->left);

		// then traverse the right subtree of the current node
		// using recursive call
		postOrder(node->right);

		// then print bid ID, bid title, bid amount, each followed by a comma, then bid fund
		cout << node->bid.bidID << ", "
			<< node->bid.bidTitle << ", "
			<< node->bid.bidAmount << ", "
			<< node->bid.bidFund << endl;
	}
}

/**
 * Traverse the tree post order (root left right)
 * parameter: pointer to the current node
 */
void BinarySearchTree::preOrder(Node* node)
{
	// FixMe (5b): Pre order root
	// check if the current node exists
	if (node != nullptr)
	{
		// if it does exist, then print bid ID, bid title, 
		// bid amount, each followed by a comma, then bid fund
		cout << node->bid.bidID << ", "
			<< node->bid.bidTitle << ", "
			<< node->bid.bidAmount << ", "
			<< node->bid.bidFund << endl;

		// traverse the left subtree of the current node
		// using recursive call
		preOrder(node->left);

		// then traverse the right subtree of the current node
		// using recursive call
		preOrder(node->right);
	}
}

/**
 * Remove a bid from some node (recursive)
 * 2 parameters: pointer to current node in tree, bid ID
 */
Node* BinarySearchTree::removeNode(Node* node, string bidId)
{
	// FIXME (7b) Implement removing a bid from the tree
	// check if the current node exists
	if (node == nullptr)
	{
		// if not, then no bid was found to remove
		return node;
	}

	// check if bid ID is less than the bid ID of the current node
	if (bidId < node->bid.bidID)
	{
		// if so, continue the search down the left subtree
		// using recursive call
		node->left = removeNode(node->left, bidId);
	}

	// check if bid ID is greater than the bid ID of the current node
	else if (bidId > node->bid.bidID)
	{
		// if so continue the search down the right subtree
		// using recursive call
		node->right = removeNode(node->right, bidId);
	}

	// if the bid ID matches the bid ID of the current node
	else
	{
		// if current node has no left child
		if (node->left == nullptr)
		{
			// assign a pointer to the right child of the current node
			Node* temp = node->right;

			// remove the node
			delete node;

			// when the node is removed, its right child will take its place in the tree
			return temp;
		}

		// if the current node has no right child
		else if (node->right == nullptr)
		{
			// assign a pointer to the left child of the current node
			Node* temp = node->left;

			// remove the node
			delete node;

			// when the node is removed, its left child will take its place in the tree
			return temp;
		}

		// assign a pointer to the right child of the current node
		// this will replace the current node
		Node* temp = node->right;

		// loop to find the leftmost node in the right subtree
		// which is the in order successor of the current node
		while (temp && temp->left != nullptr)
		{
			// assign pointer to its left child
			temp = temp->left;
		}

		// copy the bid from the in order successor's content into the current node
		// to make the node contain the bid information from the node that will replace it
		node->bid = temp->bid;

		// remove the in order successor node from the right subtree
		// the right child of the current node, and the bid Id of the in-order successor are passed 
		// in a recursive call, the results are assigned to the current node's right position
		node->right = removeNode(node->right, temp->bid.bidID);
	}

	// return the current node
	return node;
}

/**
 * method to get the root node
 */
Node* BinarySearchTree::getRootNode()
{
	// return root node
	return root;
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid)
{
	// create whitespace
	cout << endl;

	// print current bid information
	cout << bid.bidID << " : " << bid.bidTitle << " | " << bid.bidAmount << " | "
		<< bid.bidFund << endl << endl;
	return;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
void loadBids(string csvPath, BinarySearchTree* bst)
{
	// print confirmation
	cout << "Loading CSV file " << csvPath << endl;

	// initialize the CSV Parser using the given path
	csv::Parser file = csv::Parser(csvPath);

	// call method to retrieve the header section of a CSV file 
	vector<string> header = file.getHeader();

	// iterate over each element of the header section
	for (auto const& c : header)
	{
		// separate the column names
		cout << c << " | ";
	}

	// create whitespace
	cout << "" << endl;

	// try catch to handle exceptions
	try {
		// loop to read rows of a CSV file
		for (unsigned int i = 0; i < file.rowCount(); i++) {

			// Create a data structure and add to the collection of bids
			Bid bid;
			bid.bidID = file[i][1];
			bid.bidTitle = file[i][0];
			bid.bidFund = file[i][8];
			bid.bidAmount = strToDouble(file[i][4], '$');

			// push this bid to the end
			bst->Insert(bid);
		}
	}

	// catch errors in the CSV file
	catch (csv::Error& e)
	{
		// print an error message
		cerr << e.what() << endl;
	}
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch)
{
	// remove the " character
	str.erase(remove(str.begin(), str.end(), '"'), str.end());

	// remove the $ character
	str.erase(remove(str.begin(), str.end(), ch), str.end());

	// remove commas
	str.erase(remove(str.begin(), str.end(), ','), str.end());

	// remove whitespace
	str.erase(remove(str.begin(), str.end(), ' '), str.end());

	// convert string to a double
	return atof(str.c_str());
}

/**
 * This is the primary artifact enhancement for the third category: Databases
 * In this method, I will incorporate data mining in order to calculate bid statistics.
 * Specifically, this program will now contain functionality to iterate through bid dollar amounts,
 and using this information, calculate various results, such as what the average bid is,
 highest and lowest bids, sum of all bids, and the total number of bids.
 * From the main menu, users can choose to incorporate data mining of these statistics
 by choosing a numeric option.
 */
void BinarySearchTree::incorporateDataMining(Node* node)
{
	// check if there are any bids in the tree
	if (node == nullptr)
	{
		// if not, print no bids
		cout << "No bids to calculate." << endl;

		// exit the function
		return;
	}

	// declare variables
	double sumOfWinningBids = 0; // sum of all winning bids
	double highestBid = 0; // highest bid
	double lowestBid = 0; // lowest bid 
	int countBids = 0; // count the existing number of bids

	// loop to traverse the tree until there are no more nodes to process
	while (node != nullptr)
	{
		// if node has no left child
		if (node->left == nullptr)
		{
			// get the current bid amount from the current node
			// assign a variable to that amount
			double currentBidAmount = node->bid.bidAmount;

			// add the current bid amount to the sum total of all bids
			sumOfWinningBids += currentBidAmount;

			// if the current bid amount is greater than the highest bid found so far
			if (currentBidAmount > highestBid)
			{
				// then current bid amount is the highest bid
				highestBid = currentBidAmount;
			}

			// if current bid amount is less than the lowest bid found so far
			if (currentBidAmount < lowestBid)
			{
				// then current bid amount is the lowest bid
				lowestBid = currentBidAmount;
			}

			// increment the number of bids counted so far
			countBids++;

			// assign the current node pointer to its right child
			// to continue processing nodes
			node = node->right;
		}

		// if node does have a left child
		else
		{
			// assign a pointer to the left child of the current node
			// which will be used to find the rightmost node of the left subtree
			Node* predecessor = node->left;

			// loop to traverse to the rightmost child of the left subtree
			// until it finds a right child that does not exist and then points to the preceding node
			while (predecessor->right != nullptr && predecessor->right != node)
			{
				// if conditions are met, point the predecessor variable to the rightmost node
				predecessor = predecessor->right;
			}

			// if the predecessor node's right pointer is empty (no child)
			// then the current node has not been processed yet
			if (predecessor->right == nullptr)
			{
				// so assign a link from predecessor to the current node
				predecessor->right = node;

				// and point the current node to its left child
				// to continue traversing the tree
				node = node->left;
			}

			// if the predecessor node's right pointer is not empty
			// then the program processes the current node after traversing its left subtree
			else
			{
				// then remove the link from predecessor to the current node 
				// and process the current node
				predecessor->right = nullptr;

				// get the current bid amount from the current node
				// assign a variable to that amount
				double currentBidAmount = node->bid.bidAmount;

				// add the current bid amount to the sum of all winning bids
				sumOfWinningBids += currentBidAmount;

				// if current bid amount is greater than the highest bid found so far
				if (currentBidAmount > highestBid)
				{
					// then the current bid amount becomes the highest bid
					highestBid = currentBidAmount;
				}

				// if the current bid amount is less than the lowest bid found so far
				if (currentBidAmount < lowestBid)
				{
					// then the current bid amount becomes the lowest bid
					lowestBid = currentBidAmount;
				}

				// increment the number of bids counted so far
				countBids++;

				// assign the current node pointer to its right child
				// to continue processing nodes
				node = node->right;
			}
		}
	}

	// after traversing the tree
	// check if any number of bids were found
	if (countBids > 0)
	{
		// if so, calculate the average bid
		double averageAmountofBids = sumOfWinningBids / countBids;

		// print data mining results using setprecision operator for 2 decimal places
		// whitespace
		cout << endl;

		// menu
		cout << ":::Data mining results of winning bid information:::" << endl;

		// print total number of all bids
		cout << "The total number of all winning bids: " << countBids << endl;

		// print sum of all winning bids
		cout << "The sum of all winning bids: $" << fixed << setprecision(2) << sumOfWinningBids << endl;

		// print highest winning bid
		cout << "The highest winning bid: $" << fixed << setprecision(2) << highestBid << endl;

		// print lowest winning bid ($1.00)
		cout << "The lowest winning bid: $" << "1.00" << endl;

		// print average winning bid
		cout << "The average winning bid: $" << fixed << setprecision(2) << averageAmountofBids << endl << endl;
	}

	// if no bids were found
	else
	{
		// create whitespace
		cout << endl;

		// print that no bids were found
		cout << "No bids were found." << endl << endl;
	}
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[])
{
	// declare variables
	string csvPath; // CSV path
	string bidKey; // bid key
	string amount; // to contain bid amount
	string choice; // user input for switch statement
	bool condition; // condition to validate 
	clock_t ticks; // timer variable to track time in clock ticks
	BinarySearchTree* bst; // pointer to a BST object
	bst = new BinarySearchTree(); // instance of the BST class to point to its methods
	Bid bid; // instance of the Bid structure to contain bid information

	// process command line arguments in cases 2, 3, and default
	// using previously declared string variables
	if (argc == 2)
	{
		csvPath = argv[1];
		bidKey = "98223";
	}
	else if (argc == 3)
	{
		csvPath = argv[1];
		bidKey = argv[2];
	}
	else
	{
		csvPath = "eBid_Monthly_Sales.csv";
		bidKey = "98223";
	}

	// loop to print user menu
	// loop will terminate when user enters "9" as option
	while (true)
	{
		// print menu
		cout << "Menu:" << endl;
		cout << "  1. Load Bids" << endl;
		cout << "  2. Display All Bids" << endl;
		cout << "  3. Find Bid" << endl;
		cout << "  4. Add Bid" << endl;
		cout << "  5. Remove Bid" << endl;
		cout << "  6. Incorporate Data Mining" << endl;
		cout << "  9. Exit" << endl << endl;

		// prompt user for choice
		cout << "Enter choice: ";

		// get user input
		getline(cin, choice);

		// if-else structure to handle user input
		// option 1: load bids
		if (choice == "1")
		{
			// create whitespace
			cout << endl;

			// declare a timer variable before loading bids
			ticks = clock();

			// call method to load the bids
			// 2 parameters: csv path, binary search tree object
			loadBids(csvPath, bst);

			// calculate the elapsed time
			// current clock ticks minus starting clock ticks
			ticks = clock() - ticks;

			// print number of clock ticks
			cout << "time: " << ticks << " clock ticks" << endl;

			// print number of seconds
			cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl << endl;
		}

		// option 2: display all bids
		else if (choice == "2")
		{
			// call InOrder method using binary search tree pointer
			bst->InOrder();

			// create whitespace
			cout << endl;
		}

		// option 3: find bid by ID
		else if (choice == "3")
		{
			// implement loop to promp the user until valid input is recieved
			while (true)
			{
				// create whitespace
				cout << endl;

				// prompt user to find a bid by its ID
				cout << "Enter a bid's ID to find bid: ";

				// get user input
				getline(cin, bidKey);

				// if bid key field is empty
				if (bidKey.empty())
				{
					// create whitespace
					cout << endl;

					// print error
					cout << "Bid's ID field can't be empty. Please try again." << endl;

					// continue back to prompt
					continue;
				}

				// assign instance of Bid structure to the results of the search
				// and call the Search function passing the bidKey as a parameter
				bid = bst->Search(bidKey);

				// check to make sure the search matches a bid ID
				if (!bid.bidID.empty())
				{
					// call function to display bid
					displayBid(bid);

					// exit loop
					break;
				}

				// unless bid ID is not found
				else
				{
					// create whitespace
					cout << endl;

					// prompt user
					cout << "Bid ID " << bidKey << " not found. Please try again." << endl;
				}
			}
		}

		// option 4: add bid
		else if (choice == "4")
		{
			// create whitespace
			cout << endl;

			// prompt user for bid ID to add bid
			cout << "Enter bid ID to add bid: ";

			// get user input
			getline(cin, bid.bidID);

			// validate bid ID
			while (bid.bidID.empty())
			{
				// prompt
				cout << "Bid ID cannot be empty. Please try again: ";

				// get user input
				getline(cin, bid.bidID);
			}

			// prompt user for bid title
			cout << "Enter bid title: ";

			// get user input
			getline(cin, bid.bidTitle);

			// validate bid title
			while (bid.bidTitle.empty())
			{
				// prompt
				cout << "Bid title cannot be empty. Please try again: ";

				// get user input
				getline(cin, bid.bidTitle);
			}

			// prompt user for bid fund
			cout << "Enter bid fund: ";

			// get user input
			getline(cin, bid.bidFund);

			// validate bid ID
			while (bid.bidFund.empty())
			{
				// prompt
				cout << "Bid fund cannot be empty. Please try again: ";

				// get user input
				getline(cin, bid.bidFund);
			}

			// prompt user for bid amount
			cout << "Enter bid amount: ";

			// get user input
			getline(cin, amount);

			// loop to validate if bid amount is a number
			while (true)
			{
				// set validation condition to true
				condition = true;

				// if bid amount is empty
				if (amount.empty())
				{
					// prompt error
					cout << "Bid amount cannot be empty. Please try again: ";

					// condition is false
					condition = false;
				}

				// if bid amount is not empty
				else
				{
					// iterate through each character of user input
					for (char c : amount)
					{
						// if any character is not a number
						if (!isdigit(c))
						{
							// prompt
							cout << "Bid amount must be a number. Please try again: ";

							// condition is false
							condition = false;

							// end for loop
							break;
						}
					}
				}

				// if input is valid
				if (condition)
				{
					// convert string to double
					bid.bidAmount = stod(amount);

					// exit loop
					break;
				}

				// if input is invalid
				else
				{
					// get user input
					getline(cin, amount);
				}
			}

			// call insert function
			bst->Insert(bid);

			// print confirmation of bid added
			cout << "Bid was successfully added." << endl << endl;
		}

		// option 5: remove bid 
		else if (choice == "5")
		{
			// implement loop to promp the user until valid input is recieved
			while (true)
			{
				// create whitespace
				cout << endl;

				// prompt user to remove bid its ID
				cout << "Enter a bid's ID to remove bid: ";

				// get user input
				getline(cin, bidKey);

				// if bid ID field is empty
				if (bidKey.empty())
				{
					// create whitespace
					cout << endl;

					// print error
					cout << "Bid's ID field can't be empty." << endl;

					// prompt for user input again
					continue;
				}

				// if bid ID isn't in the tree 
				if (bst->Search(bidKey).bidID.empty())
				{
					// create whitespace
					cout << endl;

					// prompt user
					cout << "Bid ID " << bidKey << " not found. Please try again." << endl;

					// prompt for user input again
					continue;
				}

				// call remove function
				bst->Remove(bidKey);

				// create whitespace
				cout << endl;

				// print confirmaiton
				cout << "Bid number " << bidKey << " was removed." << endl << endl;

				// exit loop
				break;
			}
		}

		// option 6: Incorporate data mining
		else if (choice == "6")
		{
			// call getRootNode function
			bst->incorporateDataMining(bst->getRootNode());
		}

		// option 9: Exit program
		else if (choice == "9")
		{
			// print exiting the program now
			cout << "Exiting the program now." << endl;

			// exit menu loop
			break;
		}

		// validate user input
		else
		{
			// create whitespace
			cout << endl;

			// print error
			cout << "Invalid user input. Please try again." << endl << endl;
		}
	}
	return 0;
}

