
/*
* SNHU
* CS 499: Computer Science Capstone
* MOD 4 - Milestone Three - Enhancement Two: Algorithms and Data Structure
* Student Name : THOMAS SEIBERT
* The goal of this artifact enhancement is to improve the efficiency and time complexity
of an algorithm, specifically the method titled "loadDataFromFile".
* I will restructure this algorithm to pull course parameters (number, title, prereqs) 
from lines in a file, and put them into the Course structure using substring operations,
instead of a vector. As a consequence, the algorithm will get course prerequisites
in a single pass instead of separately, which will improve RAM usage.
* In addition to this artifact enhancement, comments, method names and variables will be
more descriptive and accurate where possible.
* This program is a course planner made for ABCU Computer Science department advisors.
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <string>

using namespace std;

// create Course structure to contain course information
struct Course
{
	// declare variables
	string number; // course number

	string title; // course title

	vector<string> prerequisites; // course prerequisites
};

// use unordered map as a hash table with course number as the key
unordered_map<string, Course> courses;

// declare global boolean variable to check if data has been loaded or not
bool dataLoaded = false;

// * This function, loadDataFromFile is the primary artifact enhancement.
// function to read data from a file and load data into hash table
void loadDataFromFile(string fileName) 
{
	// declare variables
	string line; // hold a line from a file
	Course course; // Course object contains the current course being processed

	// open the file
	ifstream file(fileName);

	// create whitespace 
	cout << endl;

	// if the file is not open
	if (!file.is_open()) 
	{
		// print error
		cout << "Error opening filename: " << fileName << ". Please try again." << endl << endl;

		// give user a chance to re-enter the file name if error is encountered
		return;
	}

	// clear previous course data if any
	courses.clear();

	// loop to read and get course information from lines
	// line example: "CSCI300,Introduction to Algorithms,CSCI200,MATH201"
	// to do this, comma positions will be used
	while (getline(file, line))
	{
		// clear previous prerequisite data if any
		course.prerequisites.clear();

		// find position of the first comma
		int position = line.find(',');

		// if no comma is found then the file format is automatically invalid
		// use npos string operator to represent no comma found
		if (position == string::npos)
		{
			// print error message
			cout << "File format invalid, use format found in 'CS 300 ABCU_Advising_Program_Input.csv''" << endl << endl;

			// go to next line
			continue;
		}

		// assign course number to the substring, which should exist before the first comma
		course.number = line.substr(0, position);

		// next, find position of the second comma
		int nextPosition = line.find(',', position + 1);

		// course title is after the first comma
		// if there is no second comma for prequisites, use npos operator to assign course title 
		if (nextPosition == string::npos)
		{
			// assign course title to substring 
			// starting from the character after the first comma to the end of the line
			// in this case, course title is assigned without any prerequisites
			course.title = line.substr(position + 1);
		}

		// if there is a second comma, then there are prerequisites
		else
		{
			// assign course title to substring, located between the first and second commas
			course.title = line.substr(position + 1, nextPosition - position - 1);

			// single pass iteration to get all prerequisites from a line
			// nextPosition is now set to the comma after the course title
			// loop will keep going as long as there are more commas (prerequisites) in the string
			// each iteration will update position to the last comma found until no more commas
			// use npos operator to represent no more commas found, to end loop
			while ((position = nextPosition) != string::npos)
			{
				// nextPosition will now be the next comma found after the current position
				nextPosition = line.find(',', position + 1);

				// get prerequisite course, and add it to the prerequisites vector
				course.prerequisites.push_back(line.substr(position + 1,
					nextPosition - position - 1));
			}
		}

		// assign course number
		courses[course.number] = course;
	}

	// close the file
	file.close();

	// set the boolean variable to true to indicate that data was loaded from the file
	dataLoaded = true;
}

// function to print a list of courses
// parameter is read-only reference to hash table "courses" 
// hash table uses course numbers stored in strings as keys, and Course structure as values
void printCourses(const unordered_map<string, Course>& courses) 
{
	// create a vector to hold course numbers gotten from hash table
	vector<string> courseNumbers;

	// populate the vector with course numbers
	// iterate over each keyvalue pair in the hash table
	// auto keyword makes compiler determine data type of pair based on the hash table
	// pair is a read-only reference to each course in the hash table
	// pair.first is the course number
	for (const auto& pair: courses) 
	{
		// add course number to the vector
		courseNumbers.push_back(pair.first);
	}

	// print the list of courses
	cout << "List of courses:" << endl;

	// iterate through each course number in the courseNumbers vector
	for (const string& courseNumber: courseNumbers)
	{
		// get the Course object associated with the current courseNumber from hash table
		const Course& course = courses.at(courseNumber);

		// print the course number and title
		cout << course.number << ": " << course.title << endl;
	}

	// create whitespace
	cout << endl;
}

// function to print the details of a course including prerequisites
// 2 parameters: read-only reference to hash table, read-only reference to string
void printCourseDetails(const unordered_map<string, Course>& courses,
	const string& course_name)
{
	// declare boolean variable to check if the course is found in hash table
	bool found = false;

	// search for the course by title
	// iterate through each keyvalue pair in hash table
	// pair.second is the Course object
	for (const auto& pair : courses) 
	{
		// get the Course object from the current pair and make a read-only reference to it
		const Course& course = pair.second;

		// check if the course's title matches course_name parameter
		if (course.title == course_name)
		{
			// if so, set boolean flag to true
			found = true;

			// print course number and title
			cout << "Course number: " << course.number << endl;
			cout << "Course title: " << course.title << endl;

			// check if the prerequisites vector of the found course is empty
			// if not, print course prerequisites
			if (!course.prerequisites.empty()) 
			{
				// print 
				cout << "Prerequisites: " << endl;

				// iterate thru each prerequisite in the vector
				for (const string& prerequisite : course.prerequisites)
				{
					// print 
					cout << prerequisite << endl;
				}
			}
			
			// exit loop when course is found
			break;
		}
	}

	// check if the course was not found in the hash table
	if (!found) 
	{
		// print 
		cout << "Course not found." << endl;
	}

}

// function to load data from array into hash table
void loadDataFromArray() 
{
	// hardcoded course information in an array
	string courseInformation[] = 
	{
		"CSCI100,Introduction to Computer Science",
		"CSCI101,Introduction to Programming in C++,CSCI100",
		"CSCI200,Data Structures, CSCI101",
		"MATH201,Discrete Mathematics",
		"CSCI300,Introduction to Algorithms,CSCI200,MATH201",
		"CSCI301,Advanced Programming in C++,CSCI101",
		"CSCI350,Operating Systems,CSCI300",
		"CSCI400,Large Software Development,CSCI301,CSCI350"
	};

	// iterate through each line of the array
	// line is a read-only string referencing a single course
	for (const string& line : courseInformation)
	{
		// create an input string stream from the current line
		// using this, program splits the string into individual parts using comma's
		istringstream splitStringByComma(line);

		// declare a vector to hold individual parts from the current line
		// these parts are the course number, title, prerequisites
		vector<string> courseDetails;

		// declare a string to temporarily hold a part of the current line
		string detail;

		// loop to read from input stream
		// iterating through each piece of the line splitting line by commas
		while (getline(splitStringByComma, detail, ',')) 
		{
			// add current detail to the vector
			// every course detail is added
			courseDetails.push_back(detail);
		}

		// check if the vector has less than 2 elements (no course title)
		if (courseDetails.size() < 2) 
		{
			// if so, print error message
			cout << "Invalid course format" << endl;

			// skip to the next line in the array
			continue;
		}

		// create a Course object in which to store info for the current course
		Course course;

		// assign the first element (course number) of the vector to the number field of object
		course.number = courseDetails[0];

		// assign the second element (course title) of the vector to the title field of object
		course.title = courseDetails[1];

		// iterate over the vector starting at the second element to get prerequisites
		for (int i = 2; i < courseDetails.size(); i++)
		{
			// add prerequisites to prerequisites vector from courseDetails vector using current index
			course.prerequisites.push_back(courseDetails[i]);
		}

		// store the Course object in the hash table using the course number as a key
		// necessary to prevent data loss
		courses[course.number] = course;
	}

	// set the boolean flag to true if course data was loaded successfully from the array
	dataLoaded = true;

	// print confirmation message in console
	cout << "The course data was loaded successfully from the array." << endl << endl;
}

// main function to handle user input
int main() 
{
	// declare variable to handle user input
	string user_input;

	// loop to display menu
	while (true)
	{
		// display menu options
		cout << "Menu options:" << endl;
		cout << "1. Load data from the array" << endl;
		cout << "2. Load data from a file (example: CS 300 ABCU_Advising_Program_Input.csv)" << endl;
		cout << "3. Print list of courses" << endl;
		cout << "4. Print course details (example: Introduction to Algorithms)" << endl;
		cout << "9. Exit" << endl << endl;

		// prompt user choice
		cout << "Please enter your choice: ";

		// get user input
		getline(cin, user_input);

		// create whiteline space
		cout << endl;

		// option 1: load data from the hardcoded array
		if (user_input == "1")
		{
			// call function to load data from array
			loadDataFromArray();
		}

		// option 2: load data from a file
		else if (user_input == "2")
		{
			// declare filename variable
			string fileName;

			// loop until a file is opened
			while (true)
			{
				// display prompt
				cout << "Enter filename to load data from: ";

				// clear any leftover newline character from previous input
				cin.clear();

				// get user input
				getline(cin, fileName);

				// reset boolean value in case of error
				dataLoaded = false;

				// call function to load data from file using parameter
				loadDataFromFile(fileName);

				// check if data was loaded successfully
				if (dataLoaded)
				{
					// print confirmation
					cout << "Course data loaded successfully from " << fileName << "." << endl << endl;
				}

				// ask user if they wish to go back to menu
				// declare user choice variable
				string choice;

				// print question
				cout << "Do you want to enter a filename again? If so, enter 'y': ";

				// get user input
				getline(cin, choice);

				// create whitespace
				cout << endl;

				// if choice does not equal y
				if (choice != "y") 
				{
					// exit loop and go back to menu
					break; 
				}
			}
		}

		// option 3: print list of courses
		else if (user_input == "3")
		{
			// check to see if the data is loaded
			if (dataLoaded)
			{
				// call function to print list of courses using hash table parameter
				printCourses(courses);
			}

			// if data wasn't loaded first
			else 
			{
				// print error
				cout << "Load the data first." << endl;
			}
		}

		// option 4: print course details
		else if (user_input == "4")
		{
			// check to see if data loaded
			if (dataLoaded) 
			{
				// clear the newline character if any
				cin.clear();

				// declare variable for user input
				string course_name;

				// prompt user
				cout << "Enter course title: ";

				// get user input
				getline(cin, course_name);

				// call function to print course details
				// 2 parameters: hash table, user input
				printCourseDetails(courses, course_name);

				// create whitespace
				cout << endl;
			}

			// if data wasn't loaded
			else
			{
				// print error
				cout << "Load the data first." << endl << endl;
			}
		}

		// option 9: exit
		else if (user_input == "9") 
		{
			// print confirmation
			cout << "Exiting the program now." << endl;

			// exit the loop and end the program
			break;
		}

		// invalid user input
		else
		{
			// prompt an error if user entered anything other than 1, 2, 3, 4, 9
			cout << "Invalid user input. Please try again." << endl << endl;
		}
	}

	return 0;
}
