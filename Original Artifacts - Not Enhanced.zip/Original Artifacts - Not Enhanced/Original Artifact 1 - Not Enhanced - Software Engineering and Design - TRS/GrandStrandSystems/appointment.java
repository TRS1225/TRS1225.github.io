
/**
 * SNHU
 * CS-320: Software Testing
 * MOD 6: Project One
 * Student name: THOMAS SEIBERT
 * This is the appointment class.
 * It stores appointment information.
 */

package GrandStrandSystems;

// import date
import java.util.Date;

public class appointment {

	// declare variables
	private final String appointmentId;
	private final Date appointmentDate;
	private final String description;

	// constructor
	public appointment(String appointmentId, Date appointmentDate, String description) {
		if (appointmentId == null || appointmentId.length() > 10) {
			throw new IllegalArgumentException("Appointment ID cannot be null and must be up to 10 characters.");
		}
		if (appointmentDate == null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Appointment date cannot be null and cannot be in the past.");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Description cannot be null, but can be up to 50 characters.");
		}

		// instantiate
		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}

	// get appointment ID
	public String getAppointmentId() {
		return appointmentId;
	}

	// get appointment date
	public Date getAppointmentDate() {
		return appointmentDate;
	}

	// get appointment description
	public String getDescription() {
		return description;
	}

}
