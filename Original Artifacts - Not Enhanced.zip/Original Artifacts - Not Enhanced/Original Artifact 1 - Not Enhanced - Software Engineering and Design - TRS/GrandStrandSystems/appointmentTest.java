
/**
 * SNHU
 * CS-320: Software Testing
 * MOD 6: Project One
 * Student name: THOMAS SEIBERT
 * This is the appointmentTest class.
 * It verifies that the appointment class meets the requirements through JUnit tests.
 */

package GrandStrandSystems;

// import tests
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class appointmentTest {

	// test whether or not appointment is valid
	@Test
	public void testValidAppointment() {
		appointment appointment = new appointment("1234567890", new Date(System.currentTimeMillis() + 10000),
				"Meeting");
		assertNotNull(appointment);
	}

	// test whether or not appointment ID length is valid
	@Test
	public void testAppointmentIdTooLong() {
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678901", new Date(), "Meeting");
		});
		assertEquals("Appointment ID must be non-null and up to 10 characters.", exception.getMessage());
	}

	// test whether or not the appointment date is valid
	@Test
	public void testAppointmentDateInPast() {
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", new Date(System.currentTimeMillis() - 10000), "Meeting");
		});
		assertEquals("Appointment date must be non-null and cannot be in the past.", exception.getMessage());
	}

	// test whether or not the description is valid
	@Test
	public void testDescriptionTooLong() {
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1234567890", new Date(),
					"This description is way too long and exceeds the limit of fifty characters.");
		});
		assertEquals("Description must be non-null and up to 50 characters.", exception.getMessage());
	}

}
