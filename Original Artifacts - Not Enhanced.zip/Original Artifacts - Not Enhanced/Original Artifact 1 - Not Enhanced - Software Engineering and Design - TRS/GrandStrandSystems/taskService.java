
/**
 * SNHU
 * CS-320: Software Testing
 * MOD 6: Project One
 * Student name: THOMAS SEIBERT
 * This is the taskService class.
 * It may add, update or delete tasks.
 */

package GrandStrandSystems;

// import array
import java.util.ArrayList;

public class taskService {

	// declare and instantiate array
	private final ArrayList<task> tasks = new ArrayList<>();

	// add task method
	public void addTask(task task) {
		for (task t : tasks) {
			if (t.getTaskId().equals(task.getTaskId())) {
				throw new IllegalArgumentException("Task ID must be unique.");
			}
		}
		tasks.add(task);
	}

	// delete task method
	public void deleteTask(String taskId) {
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getTaskId().equals(taskId)) {
				tasks.remove(i);
				return;
			}
		}
		throw new IllegalArgumentException("Task ID not found.");
	}

	// update task method
	public void updateTask(String taskId, String name, String description) {
		for (task task : tasks) {
			if (task.getTaskId().equals(taskId)) {
				if (name != null) {
					task.setName(name);
				}
				if (description != null) {
					task.setDescription(description);
				}
				return;
			}
		}
		throw new IllegalArgumentException("Task ID not found.");
	}
}
