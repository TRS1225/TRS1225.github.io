
/**
 * SNHU
 * CS-320: Software Testing
 * MOD 6: Project One
 * Student name: THOMAS SEIBERT
 * This is the taskTest class.
 * It verifies that the task class meets the requirements through JUnit tests.
 */

package GrandStrandSystems;

// import tests
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class taskTest {

	// this tests for task creation
	@Test
	public void testTaskCreation() {
		task task = new task("1234567890", "Test Task", "This is a test description.");
		assertEquals("1234567890", task.getTaskId());
		assertEquals("Test Task", task.getName());
		assertEquals("This is a test description.", task.getDescription());
	}

	// this tests for task ID length
	@Test
	public void testTaskIdLength() {
		assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Description"));
		assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Description"));
	}

	// this tests for name length
	@Test
	public void testNameLength() {
		assertThrows(IllegalArgumentException.class, () -> new Task("1234567890", null, "Description"));
		assertThrows(IllegalArgumentException.class,
				() -> new Task("1234567890", "This name is way too long", "Description"));
	}

	// this tests for description length
	@Test
	public void testDescriptionLength() {
		assertThrows(IllegalArgumentException.class, () -> new Task("1234567890", "Name", null));
		assertThrows(IllegalArgumentException.class, () -> new Task("1234567890", "Name",
				"This description is way too long and exceeds the limit of fifty characters."));
	}

}
