
/**
 * SNHU
 * CS-320: Software Testing
 * MOD 6: Project One
 * Student name: THOMAS SEIBERT
 * This is the task class.
 * It stores task information.
 */

package GrandStrandSystems;

public class task {

	// declare variables
	private final String taskId;
	private String name;
	private String description;

	// constructor
	public task(String taskId, String name, String description) {
		if (taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Task ID cannot be null and must be 10 characters or less.");
		}
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Name cannot be null and must be 20 characters or less.");
		}
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Description cannot be null and must be 50 characters or less.");
		}

		// instantiate
		this.taskId = taskId;
		this.name = name;
		this.description = description;
	}

	// get task ID
	public String getTaskId() {
		return taskId;
	}

	// get name
	public String getName() {
		return name;
	}

	// set name
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Name cannot be null and must be 20 characters or less.");
		}
		this.name = name;
	}

	// get description
	public String getDescription() {
		return description;
	}

	// set description
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Description cannot be null and must be 50 characters or less.");
		}
		this.description = description;
	}

}
