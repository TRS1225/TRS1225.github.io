
/**
 * SNHU
 * CS-320: Software Testing
 * MOD 6: Project One
 * Student name: THOMAS SEIBERT
 * This is the appointmentServiceTest class.
 * It verifies that the appointmentService class meets the requirements through JUnit tests.
 */

package GrandStrandSystems;

// import tests
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class appointmentServiceTest {

	// test to add appointment
	@Test
	public void testAddAppointment() {
		appointmentService service = new appointmentService();
		appointment appointment = new appointment("1234567890", new Date(System.currentTimeMillis() + 10000),
				"Meeting");
		service.addAppointment(appointment);
		assertEquals(1, service.appointments.size());
	}

	// tests whether an appointment is a duplicate or not
	@Test
	public void testAddDuplicateAppointment() {
		appointmentService service = new appointmentService();
		appointment appointment1 = new appointment("1234567890", new Date(System.currentTimeMillis() + 10000),
				"Meeting");
		appointment appointment2 = new appointment("1234567890", new Date(System.currentTimeMillis() + 20000),
				"Another Meeting");
		service.addAppointment(appointment1);
		Exception exception = assertThrows(IllegalArgumentException.class, () -> {
			service.addAppointment(appointment2);
		});
		assertEquals("Appointment ID must be unique.", exception.getMessage());
	}

	// tests whether or not appointment has been deleted
	@Test
	public void testDeleteAppointment() {
		appointmentService service = new appointmentService();
		appointment appointment = new appointment("1234567890", new Date(System.currentTimeMillis() + 10000),
				"Meeting");
		service.addAppointment(appointment);
		service.deleteAppointment("1234567890");
		assertEquals(0, service.appointments.size());
	}

}
