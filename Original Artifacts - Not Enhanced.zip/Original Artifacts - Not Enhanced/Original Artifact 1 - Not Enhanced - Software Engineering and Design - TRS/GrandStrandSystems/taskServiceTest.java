
/**
 * SNHU
 * CS-320: Software Testing
 * MOD 6: Project One
 * Student name: THOMAS SEIBERT
 * This is the taskServiceTest class.
 * It verifies that the taskService class meets the requirements through JUnit tests.
 */

package GrandStrandSystems;

// import tests
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class taskServiceTest {

	// test to add task
	@Test
	public void testAddTask() {
		taskService service = new taskService();
		task task = new task("1234567890", "Test Task", "This is a test description.");
		service.addTask(task);
		assertEquals(1, service.getTasks().size());
		assertEquals(task, service.getTasks().get(0));
	}

	// test to delete task
	@Test
	public void testDeleteTask() {
		taskService service = new taskService();
		task task = new task("1234567890", "Test Task", "This is a test description.");
		service.addTask(task);
		service.deleteTask("1234567890");
		assertEquals(0, service.getTasks().size());
	}

	// test to update task
	@Test
	public void testUpdateTask() {
		taskService service = new taskService();
		task task = new task("1234567890", "Test Task", "This is a test description.");
		service.addTask(task);
		service.updateTask("1234567890", "Updated Task", "Updated description.");
		assertEquals("Updated Task", service.getTasks().get(0).getName());
		assertEquals("Updated description.", service.getTasks().get(0).getDescription());
	}

}
