
/**
 * SNHU
 * CS-320: Software Testing
 * MOD 6: Project One
 * Student name: THOMAS SEIBERT
 * This is the appointmentService class.
 * It can add or delete appointments.
 */

package GrandStrandSystems;

// import array
import java.util.ArrayList;
import java.util.List;

public class appointmentService {

	// declare and instantiate array
	private final List<appointment> appointments = new ArrayList<>();

	// method to add appointment
	public void addAppointment(appointment appointment) {
		for (appointment a : appointments) {
			if (a.getAppointmentId().equals(appointment.getAppointmentId())) {
				throw new IllegalArgumentException("Appointment ID must be unique.");
			}
		}
		appointments.add(appointment);
	}

	// method to delete appointment
	public void deleteAppointment(String appointmentId) {
		for (int i = 0; i < appointments.size(); i++) {
			if (appointments.get(i).getAppointmentId().equals(appointmentId)) {
				appointments.remove(i);
				return;
			}
		}
		throw new IllegalArgumentException("Appointment ID not found.");
	}

}
