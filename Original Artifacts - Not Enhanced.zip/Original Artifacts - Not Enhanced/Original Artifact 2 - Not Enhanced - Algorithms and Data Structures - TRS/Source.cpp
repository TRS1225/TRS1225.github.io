
// SNHU
// CS 300
// MOD 7: PROJECT TWO
// STUDENT NAME : THOMAS SEIBERT
// This program is a course planner made for ABCU Computer Science department advisors.

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <string>

using namespace std;

// create struct Course to contain course information
struct Course {
	// course number
	string number;

	// course title
	string title;

	// list of prerequisite courses
	vector<string> prerequisites;
};

// Use unordered map as a hash table with course number as the key
unordered_map<string, Course> courses;

// declare global boolean variable to check if data has been loaded or not
bool dataLoaded = false;

// Function to read data from a file and load it into hash table
void loadDataFromFile(string fileName) 
{
	// declare variables
	string line;
	Course course;

	// if statement to check file opening error 
	ifstream file(fileName);
	if (!file.is_open())
	{
		// print error
		cout << "File failed to open, try again" << endl;

		// give user a chance to re-enter the file name if error
		return;
	}

	// clear previous data if any
	courses.clear();

	// loop to get lines from the file
	while (getline(file, line))
	{
		// create a stream from the line
		istringstream iss(line);

		// declare a vector to hold parts from the line
		vector<string> parts;

		// declare a string to hold a part from the line
		string part;

		// split the line by commas
		while (getline(iss, part, ',')) 
		{
			parts.push_back(part);
		}

		// validation
		if (parts.size() < 2) {
			cout << "Invalid file format" << endl;
			continue;
		}

		// declare course parts
		course.number = parts[0];
		course.title = parts[1];

		// add prerequisites
		// check if the parts vector contains more than two elements
		if (parts.size() > 2)
		{
			// iterate through elements in the parts vector after 2
			// that come after the course number and title
			for (int i = 2; i < parts.size(); i++) 
			{
				// build a list of prerequisites for the current course being processed
				course.prerequisites.push_back(parts[i]);
			}
		}

		// declare course number
		courses[course.number] = course;
	}

	// close the file
	file.close();

	// set the boolean variable to true if data was loaded from the file
	dataLoaded = true;
}

// function to print courses in an ordered manner
void printOrderedCourses(const unordered_map<string, Course>& courses) {

	// create a vector to store course numbers
	vector<string> courseNumbers;

	// populate the vector with course numbers
	for (const auto& pair : courses) 
	{
		// add course number to the vector
		courseNumbers.push_back(pair.first);
	}

	// print the sorted list of courses
	cout << "List of courses:" << endl;

	// loop through course numbers to sort them
	for (const string& courseNumber : courseNumbers)
	{
		// get the course
		const Course& course = courses.at(courseNumber);

		// print the course details
		cout << course.number << ": " << course.title << endl;
	}

}

// function to print details about a course
void printCourseDetails(const unordered_map<string, Course>& courses,
	const string& course_name)
{
	// declare boolean variable to check if the course is found or not
	bool found = false;

	// search for the course by title
	for (const auto& pair : courses) 
	{
		// get the course object
		const Course& course = pair.second;

		// check if the course's title matches
		if (course.title == course_name)
		{
			// if so, set boolean flag to true
			found = true;

			// display course number and title
			cout << "Course number: " << course.number << endl;
			cout << "Course title: " << course.title << endl;

			// list prerequisites if they exist
			if (!course.prerequisites.empty()) 
			{
				// console output
				cout << "Prerequisites: " << endl;

				// cycle through prerequisites
				for (const string& prerequisite : course.prerequisites)
				{
					// print prerequisites
					cout << prerequisite << endl;
				}
			}

			// if there aren't any prerequisites, print it
			else 
			{
				cout << "No prerequisites for this course." << endl;
			}
			
			// exit loop when course is found
			break;
		}
	}

	// if the course is not found, print a message
	if (!found) 
	{
		cout << "Course not found" << endl;
	}

}

// Function to read file and parse data into hash table
void loadDataFromArray() 
{
	// hardcoded course information in an array
	string courseInformation[] = {
		"CSCI100,Introduction to Computer Science",
		"CSCI101,Introduction to Programming in C++,CSCI100",
		"CSCI200,Data Structures, CSCI101",
		"MATH201,Discrete Mathematics",
		"CSCI300,Introduction to Algorithms,CSCI200,MATH201",
		"CSCI301,Advanced Programming in C++,CSCI101",
		"CSCI350,Operating Systems,CSCI300",
		"CSCI400,Large Software Development,CSCI301,CSCI350"
	};

	// loop through each line of the course information
	for (const string& line : courseInformation)
	{
		// create a stream from the line
		istringstream iss(line);

		// declare a vector to hold parts from the line
		vector<string> parts;

		// declare a string to hold a part from the line
		string part;

		// split the line by commas
		while (getline(iss, part, ',')) 
		{
			// add each part to the vector
			parts.push_back(part);
		}

		// check if the line has at least a number and a title
		if (parts.size() < 2) 
		{
			cout << "Invalid course format" << endl;

			// skip to the next line if valid
			continue;
		}

		// create a course object and populate its fields
		Course course;

		// first part is the course number
		course.number = parts[0];

		// second part is the course title
		course.title = parts[1];

		// add any prerequisites to the course
		for (size_t i = 2; i < parts.size(); i++)
		{
			// add prerequisites
			course.prerequisites.push_back(parts[i]);
		}

		// store the course in the global unordered map
		courses[course.number] = course;
	}

	// set the boolean flag to true if data was loaded successfully
	dataLoaded = true;

	// print the confirmation message in console
	cout << "The course data was loaded successfully." << endl;
}

// Main function containing menu and user interaction
int main() {
	// declare variable to store user input
	int user_input;

	// loop to display menu
	while (true)
	{
		cout << "1. Load data from the array" << endl;
		cout << "2. Load data from a file" << endl;
		cout << "3. Print ordered list of courses" << endl;
		cout << "4. Print course details" << endl;
		cout << "9. Exit" << endl;

		// get user input
		cin >> user_input;

		// option 1 - load data from the hardcoded array
		if (user_input == 1)
		{
			// load data into the courses map
			loadDataFromArray();
		}

		// option 2 - load data from a file
		else if (user_input == 2)
		{
			// declare filename variable
			string fileName;

			// loop until a file is opened
			while (true)
			{
				// display prompt
				// example: "CS 300 ABCU_Advising_Program_Input.csv"
				cout << "Enter filename to load data from: ";

				// clear any leftover newline character from previous input
				cin.ignore();

				// get user input
				getline(cin, fileName);

				// reset boolean value in case of error loop
				dataLoaded = false;

				// call function to load data from a file
				loadDataFromFile(fileName);

				// check if the data was loaded successfully
				if (dataLoaded)
				{
					// if data was loaded succesffuly
					cout << "Course data loaded successfully from " << fileName << "." << endl;
				}
				else
				{
					// print error message
					cout << "Error opening filename: " << fileName << "." << endl;
				}

				// ask user if they wish to go back to menu
				string choice;
				cout << "Do you want to enter a filename again? If so, enter 'y': ";
				getline(cin, choice);

				// if choice does not equal y
				if (choice != "y") 
				{
					// exit loop and go back to menu
					break; 
				}
			}
		}

		// option 3 - print ordered list of courses
		else if (user_input == 3)
		{
			// check to see if the data is loaded
			if (dataLoaded)
			{
				// call the function
				printOrderedCourses(courses);
			}
			else 
			{
				// if not
				cout << "Load the data first." << endl;
			}
		}

		// option 4 - print course details
		else if (user_input == 4)
		{
			// check to see if data loaded
			if (dataLoaded) 
			{
				// clear the newline character from before
				cin.ignore();

				// declare variable for user input
				string course_name;

				// get user input
				// for example: "Introduction to Algorithms"
				cout << "Enter course title: ";

				// must be entered exactly as it appears in menu
				// for example: "Introduction to Computer Science"
				getline(cin, course_name);

				// call the function
				printCourseDetails(courses, course_name);
			}
			else
			{
				// if not
				cout << "Load the data first." << endl;
			}
		}

		// option 9 - exit
		else if (user_input == 9) 
		{
			// console confirmation
			cout << "Exiting the program now." << endl;

			// exit the loop and end the program
			break;
		}
		else
		{
			// if there was an error exiting the program
			cout << "Invalid option. Please try again." << endl;
		}
	}

	return 0;
}
