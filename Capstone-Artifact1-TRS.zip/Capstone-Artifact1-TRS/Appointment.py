"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the Appointment class.
It stores appointment information and defines constraints on information.
"""

from datetime import datetime

# declare class
class Appointment:

    # constructor
    def __init__(self, appointment_id, appointment_date, appointment_description):

        # set constraints for appointment ID: can't be empty or greater than 10 characters
        if appointment_id is None or len(appointment_id) > 10:
            raise ValueError("Appointment ID cannot be empty and must be up to 10 characters.")

        # set constraints for appointment date: can't be empty or in the past
        if appointment_date is None or appointment_date < datetime.now():
            raise ValueError("Appointment date cannot be empty and cannot be in the past.")

        # set constraints for appointment description: can't be empty or greater than 50 characters
        if appointment_description is None or len(appointment_description) > 50:
            raise ValueError("Description cannot be empty, but can be up to 50 characters.")

        # assign validated variables to private variables
        self.appointment_id = appointment_id
        self.appointment_date = appointment_date
        self.appointment_description = appointment_description

    # use property decorators to define GET method attributes
    # GET appointment ID
    @property
    def get_appointment_id(self):
        return self.appointment_id

    # GET appointment date
    @property
    def get_appointment_date(self):
        return self.appointment_date

    # GET appointment description
    @property
    def get_appointment_description(self):
        return self.appointment_description


