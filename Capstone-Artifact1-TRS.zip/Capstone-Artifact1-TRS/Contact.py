
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the Contact class.
It contains Contact information and their constraints.
"""

# define class
class Contact:

    # constructor
    def __init__(self, contact_id, first_name, last_name, phone, address):

        # set constraints for contact id
        if contact_id is None or len(contact_id) > 10:
            raise ValueError("Contact ID cannot be empty and cannot be more than 10 characters.")

        # set constraints for first name
        if first_name is None or len(first_name) > 10:
            raise ValueError("First name cannot be empty and cannot be more than 10 characters.")

        # set constraints for last name
        if last_name is None or len(last_name) > 10:
            raise ValueError("Last name cannot be empty and cannot be more than 10 characters.")

        # set constraints for phone number
        if phone is None or len(phone) != 10 or not phone.isdigit():
            raise ValueError("Phone number must be exactly 10 digits.")

        # set constraints for address
        if address is None or len(address) > 30:
            raise ValueError("Address cannot be empty and cannot be more than 30 characters.")

        # assign validated variables to private variables
        # make contact id private in accord with previous JAVA program
        self._contact_id = contact_id
        self.first_name = first_name
        self.last_name = last_name
        self.phone = phone
        self.address = address

    # GET contact id
    def get_contact_id(self):
        return self._contact_id

    # GET first name
    def get_first_name(self):
        return self.first_name

    # GET last name
    def get_last_name(self):
        return self.last_name

    # GET phone number
    def get_phone(self):
        return self.phone

    # GET address
    def get_address(self):
        return self.address

    # SET first name
    def set_first_name(self, first_name):
        # validate
        if first_name is None or len(first_name) > 10:
            raise Exception("First name cannot be empty and cannot be more than 10 characters.")

        # assign
        self.first_name = first_name

    # SET last name
    def set_last_name(self, last_name):
        # validate
        if last_name is None or len(last_name) > 10:
            raise Exception("Last name cannot be empty and cannot be more than 10 characters.")

        # assign
        self.last_name = last_name

    # SET phone number
    def set_phone(self, phone):
        # validate
        if phone is None or len(phone) != 10 or not phone.isdigit():
            raise Exception("Phone number must be exactly 10 digits.")

        # assign
        self.phone = phone

    # SET address
    def set_address(self, address):
        # validate
        if address is None or len(address) > 30:
            raise Exception("Address cannot be empty and cannot be more than 30 characters.")

        # assign
        self.address = address

