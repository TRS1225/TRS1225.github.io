
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the AppointmentTest class.
It verifies that the Appointment class meets its requirements through
the unittest PYTHON framework.
"""

import unittest
from datetime import datetime, timedelta
from Appointment import Appointment


# define class
class AppointmentTest(unittest.TestCase):

    # test whether appointment itself is valid or not
    def test_valid_appointment(self):
        # create new appointment with parameters
        appointment = Appointment("1234567890", datetime.now() + timedelta(seconds=30),
                                  "Meeting")

        # assert that the appointment object is not none
        self.assertIsNotNone(appointment)

    # test whether appointment ID length is valid or not
    def test_appointment_id_length(self):
        # check to see whether creating an appointment with a length > 10 characters throws an error
        with self.assertRaises(ValueError) as context:

            # use future date to avoid errors
            future_date = datetime.now() + timedelta(seconds=30)

            Appointment("12345678901", future_date, "Meeting")

        # assert that error message is working
        self.assertEqual(str(context.exception), "Appointment ID cannot be empty"
                                                 " and must be up to 10 characters.")

    # test whether the appointment date is valid or not
    def test_appointment_date(self):
        # check to see whether creating an appointment in the past throws an error
        with self.assertRaises(ValueError) as context:
            Appointment("1234567890", datetime.now() - timedelta(seconds=30),
                        "Meeting")

        # assert that error message is working
        self.assertEqual(str(context.exception), "Appointment date cannot be empty"
                                                 " and cannot be in the past.")

    # test whether the appointment description is valid or not
    def test_appointment_description(self):
        # check to see whether creating an appointment with a description
        # of more than 50 characters throws an error
        with self.assertRaises(ValueError) as context:

            # use future date to avoid errors
            future_date = datetime.now() + timedelta(seconds=30)

            Appointment("1234567890", future_date, "This description is far too"
                                                      " much and it exceeds the limit of fifty characters.")

        # assert that error message is working
        self.assertEqual(str(context.exception), "Description cannot be empty, but can be up to 50 characters.")

# run unittest framework
if __name__ == '__main__':
    unittest.main()





