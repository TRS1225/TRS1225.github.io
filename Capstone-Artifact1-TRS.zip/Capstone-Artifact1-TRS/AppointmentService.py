
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the AppointmentService class.
It can add or delete appointments.
"""

# declare class
class AppointmentService:

    # constructor
    def __init__(self):
        # define a list named appointments to contain the appointments
        self.appointments = []

    # method to add appointment
    def add_appointment(self, appointment):
        # make sure the appointment ID is unique
        # iterate through list
        for i in self.appointments:
            if i.get_appointment_id == appointment.get_appointment_id:
                raise ValueError("Appointment ID must be unique.")

        # add appointment to the list
        self.appointments.append(appointment)


    #method to delete appointment
    def delete_appointment(self, appointment):
        # iterate through list
        # use range and len operators to use index for deletions
        for i in range(len(self.appointments)):
            # check to see if the current appointment matches appointment to be deleted
            if self.appointments[i].get_appointment_id == appointment.get_appointment_id:
                # delete appointment from list
                del self.appointments[i]
                # exit method
                return
        # prompt user if the appointment is not found
        raise Exception("Error: Appointment not found")
