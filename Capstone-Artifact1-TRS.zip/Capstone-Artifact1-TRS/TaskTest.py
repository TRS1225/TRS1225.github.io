
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the TaskTest class.
It verifies that the Task class meets its requirements via the unittest framework of PYTHON.
"""

import unittest
from Task import Task

# define class
class TaskTest(unittest.TestCase):

    # this method tests for a successful task creation
    def test_task_creation(self):
        # instantiate a new task object
        task = Task("1234567890", "Test Task", "This is a test description.")

        # assert task id is correct
        self.assertEqual("1234567890", task.get_task_id())

        # assert task name is correct
        self.assertEqual("Test Task", task.get_name())

        # assert task description is correct
        self.assertEqual("This is a test description.", task.get_description())

    # this method tests task id length
    def test_task_id_length(self):
        # assert that creation of a task with an empty id is an error
        with self.assertRaises(Exception):
            Task(None, "Test Task", "This is a test description.")

        # assert that creation of a task id > 10 characters is an error
        with self.assertRaises(Exception):
            Task("12345678901", "Test Task", "This is a test description.")

    # this method tests for task name length
    def test_task_name_length(self):
        # assert that creation of a task with an empty name is an error
        with self.assertRaises(Exception):
            Task("1234567890", None, "This is a test description.")

        # assert that creation of a task with a name > 20 characters is an error
        with self.assertRaises(Exception):
            task = Task("1234567890", "This name has far too many characters"
                                      " for this application",
                        "This is a test description.")

    # this method tests for task description length
    def test_task_description_length(self):
        # assert that creation of a task with an empty description is an error
        with self.assertRaises(Exception):
            Task("1234567890", "Name", None)

        # assert that creation of task with a description > 50 characters is an error
        with self.assertRaises(Exception):
            Task("1234567890", "Name", "This description has far too many characters"
                                       " and"
                                       " exceeds the limit of fifty characters.")

# run unittest framework
if __name__ == '__main__':
    unittest.main()
