
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the Task class.
It contains Task information and their constraints.
"""

# define class
class Task:

    # constructor
    def __init__(self, task_id, name, description):
        # define task id constraints: can't be empty or greater than 10 characters
        if task_id is None or len(task_id) > 10:
            raise Exception("Task ID cannot be empty and must be 10 characters or less.")

        # define name constraints: can't be empty or greater than 20 characters
        if name is None or len(name) > 20:
            raise Exception("Name cannot be null and must be 20 characters or less.")

        # define description constraints: can't be empty or greater than 50 characters
        if description is None or len(description) > 50:
            raise Exception("Description cannot be empty and must be 50 characters or less.")

        # instantiate variables
        # make task id private
        self._task_id = task_id
        self._name = name
        self._description = description

    # GET task id
    def get_task_id(self):
        return self._task_id

    # GET name
    def get_name(self):
        return self._name

    # GET description
    def get_description(self):
        return self._description

    # SET name
    def set_name(self, name):
        # check constraints
        if name is None or len(name) == 0 or len(name) > 20:
            raise Exception("Name cannot be empty and must be 20 characters or less.")

        # assign
        self._name = name

    # SET description
    def set_description(self, description):
        # check constraints
        if description is None or len(description) == 0 or len(description) > 50:
            raise Exception("Description cannot be empty and must be 50 characters or less.")

        # assign
        self._description = description

    # Don't need a SET task id since it is immutable

