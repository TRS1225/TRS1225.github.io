
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the ContactServiceTest class.
It verifies that the ContactService class meets its requirements through
the unittests framework of PYTHON.
"""

import unittest
from ContactService import ContactService
from Contact import Contact

# define class
class ContactServiceTest(unittest.TestCase):

    # test method to add a contact
    def test_add_contact(self):

        # create instance of ContactService
        service = ContactService()

        # create new contact
        contact = Contact("1234567890", "John", "Doe",
                          "1234567890", "123 Main St")

        # add contact to service
        service.add_contact(contact)

        # assert that contact size is equal to 1
        self.assertEqual(1, len(service.contacts))

    # test method to delete a contact
    def test_remove_contact(self):

        # create instance of ContactService
        service = ContactService()

        # create new contact
        contact = Contact("1234567890", "John", "Doe",
                          "1234567890", "123 Main St")

        # add contact to service
        service.add_contact(contact)

        # delete contact using phone number
        service.delete_contact(contact)

        # assert that contact size is equal to 0
        self.assertEqual(0, len(service.contacts))

    # test method to update a contact
    def test_update_contact(self):

        # create instance of ContactService
        service = ContactService()

        # create new contact
        contact = Contact("1234567890", "John", "Doe",
                          "1234567890", "123 Main St")

        # add contact to service
        service.add_contact(contact)

        # update the contact
        service.update_contact("1234567890", "Jane", "Doe",
                               "0987654321", "456 Elm St")

        # assert first name update
        self.assertEqual("Jane", service.contacts[0].first_name)

        # assert phone number update
        self.assertEqual("0987654321", service.contacts[0].phone)

# run unittest framework
if __name__ == '__main__':
    unittest.main()
