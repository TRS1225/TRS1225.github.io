
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the ContactTest class.
It verifies that the Contact class meets its requirements via
the unittests framework of PYTHON.
"""

import unittest
from Contact import Contact

# define class
class ContactTest(unittest.TestCase):

    # test whether the creation of a contact is valid
    def test_invalid_contact_creation(self):
        # create new contact
        contact = Contact("1234567890", "John", "Doe", "1234567890", "123 Main St")

        # assert correct first name
        self.assertTrue(contact.get_first_name() == "John")

        # assert correct last name
        self.assertEqual(contact.get_last_name(), "Doe")

        # assert correct phone number
        self.assertEqual(contact.get_phone(), "1234567890")

        # assert correct address
        self.assertEqual(contact.get_address(), "123 Main St")

    # test whether contact ID is valid
    def test_invalid_contact_id(self):
        # assert that creation of a contact with an empty id is invalid
        with self.assertRaises(ValueError):
            Contact(None, "John", "Doe", "1234567890", "123 Main St")

    # test whether first name is valid
    def test_invalid_first_name(self):
        # assert that creation of a contact with an empty first name is invalid
        with self.assertRaises(ValueError):
            Contact("1234567890", None, "Doe", "1234567890", "123 Main St")

    # test whether last name is valid
    def test_invalid_last_name(self):
        # assert that creation of a contact with an empty last is invalid
        with self.assertRaises(ValueError):
            Contact("1234567890", "John", None, "1234567890", "123 Main St")

    # test whether phone number is valid
    def test_invalid_phone_number(self):
        # assert that creation of a contact with a phone number of less than 10 digits is invalid
        with self.assertRaises(ValueError):
            Contact("1234567890", "John", "Doe", "12345", "123 Main St")

    # test whether address is valid
    def test_invalid_address(self):
        # assert that creation of a contact with an empty address is invalid
        with self.assertRaises(ValueError):
            Contact("1234567890", "John", "Doe", "1234567890", None)

# run unittest framework
if __name__ == '__main__':
    unittest.main()





