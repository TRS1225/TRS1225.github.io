
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the TaskServiceTest class.
It verifies that the TaskService class meets its requirements via the unittest framework of PYTHON.
"""

import unittest
from TaskService import TaskService
from Task import Task

# define class
class TaskServiceTest(unittest.TestCase):

    # test method to add a task
    def test_add_task(self):

        # instantiate TaskService
        service = TaskService()

        # create a new task
        task = Task("1234567890", "Test Task", "This is a test description.")

        # add task to service
        service.add_task(task)

        # assert that task size equals 1
        self.assertEqual(1, len(service.tasks))

        # assert that the first task in the service is the task that is added
        self.assertEqual(task, service.tasks[0])

    # test method to delete a task
    def test_delete_task(self):

        # instantiate TaskService
        service = TaskService()

        # create a new task
        task = Task("1234567890", "Test Task", "This is a test description.")

        # add task to service
        service.add_task(task)

        # delete task using id
        service.delete_task("1234567890")

        # assert that task size equals 0
        self.assertEqual(0, len(service.tasks))

    # test method to update a task
    def test_update_task(self):

        # instantiate TaskService
        service = TaskService()

        # create a new task
        task = Task("1234567890", "Test Task", "This is a test description.")

        # add task to service
        service.add_task(task)

        # update a task
        service.update_task("1234567890", "Updated task", "Updated task description.")

        # assert that the first task's name is now updated
        self.assertEqual("Updated task", service.tasks[0].get_name())

        # assert that the first task's description is now updated
        self.assertEqual("Updated task description.", service.tasks[0].get_description())

# run unittest framework
if __name__ == '__main__':
    unittest.main()
