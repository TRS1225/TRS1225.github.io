
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the ContactService class.
It contains functionality to add, update or delete contacts.
"""

from Contact import Contact

# define class
class ContactService:

    # constructor
    def __init__(self):
        # use list instead of array to contain contacts
        self.contacts: list[Contact] = []

    # method to add contact
    def add_contact(self, contact: Contact):
        # iterate through contacts to find the contact to add
        for i in self.contacts:
            if i.get_contact_id() == contact.get_contact_id():

                # print error
                raise Exception("Error: This contact id already exists.")

        # add contact to list
        self.contacts.append(contact)

    # method to delete contact
    def delete_contact(self, contact: Contact):
        # iterate through contacts
        for i in range(len(self.contacts)):
            if self.contacts[i].get_contact_id() == contact.get_contact_id():

                # delete the contact
                del self.contacts[i]

                # exit
                return

        # print an error if contact not found
        raise Exception("Error: This contact doesn't exist.")

    # method to update contact
    def update_contact(self, contact_id, first_name, last_name, phone, address):
        # iterate through contacts
        for i in self.contacts:
            if i.get_contact_id() == contact_id:

                # update the contacts
                if first_name is not None:
                    i.set_first_name(first_name)

                if last_name is not None:
                    i.set_last_name(last_name)

                if phone is not None:
                    i.set_phone(phone)

                if address is not None:
                    i.set_address(address)

                # exit
                return

        # throw error if contact is not found
        raise Exception("Error: This contact doesn't exist.")









