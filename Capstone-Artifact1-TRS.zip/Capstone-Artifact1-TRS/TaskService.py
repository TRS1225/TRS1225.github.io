
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the TaskService class.
It contains functionality to add, update or delete tasks.
"""

# define class
class TaskService:

    # constructor
    def __init__(self):
        # declare a list to contain tasks
        self.tasks = []

    # method to add a task
    def add_task(self, task):
        # check if task already exists in the list
        for i in self.tasks:

            # check current task id against task id
            if i.get_task_id() == task.get_task_id():

                # prompt an error
                raise Exception('Task already exists')

        # add task to the list
        self.tasks.append(task)

    # method to delete a task
    def delete_task(self, task_id):
        # iterate through list
        for i in range(len(self.tasks)):

            # check current task against given task
            if self.tasks[i].get_task_id() == task_id:

                # delete task from list if found
                del self.tasks[i]

                # exit
                return

        # prompt an error if task id not found
        raise Exception('Task does not exist')

    # method to update a task
    def update_task(self, task_id, name, description):
        # iterate through list
        for task in self.tasks:

            # check current task against given task id
            if task.get_task_id() == task_id:

                # update task's name
                if name is not None:
                    task.set_name(name)

                # update task's description
                if description is not None:
                    task.set_description(description)

                # exit
                return

        # prompt error if task is not found
        raise Exception('Task does not exist')


