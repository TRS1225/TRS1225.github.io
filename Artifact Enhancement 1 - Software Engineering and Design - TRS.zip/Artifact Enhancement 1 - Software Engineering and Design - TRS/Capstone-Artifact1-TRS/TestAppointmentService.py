
"""
SNHU
CS-499: Computer Science Capstone
MOD 3 - Milestone Two - Enhancement One - Software Design and Engineering
Student name: THOMAS SEIBERT
The goal of this artifact enhancement is to convert a JAVA program into PYTHON.
This is the AppointmentServiceTest class.
It verifies that the AppointmentService class meets its requirements through
the unittest PYTHON framework.
"""

import unittest
from datetime import datetime, timedelta
from AppointmentService import AppointmentService
from Appointment import Appointment


# define class
class AppointmentServiceTest(unittest.TestCase):

    # test method to add an appointment
    def test_add_appointment(self):

        # create instance of AppointmentService
        service = AppointmentService()

        # create new appointment with parameters
        appointment = Appointment("1234567890", datetime.now() + timedelta(seconds=30),
                                  "Meeting")

        # add appointment to service
        service.add_appointment(appointment)

        # assert the number of appointments is equal to 1
        self.assertEqual(len(service.appointments), 1)

    # test whether an appointment is a duplicate or not
    def test_duplicate_appointment(self):

        # create new instance of AppointmentService
        service = AppointmentService()

        # create first appointment with parameters
        appointment_1 = Appointment("1234567890", datetime.now() + timedelta(seconds=30),
                                    "Meeting")

        # create second appointment with parameters
        appointment_2 = Appointment("1234567890", datetime.now() + timedelta(seconds=40),
                                    "Second Meeting")

        # add appointment to service
        service.add_appointment(appointment_1)

        # assert that adding the other meeting raises an exception error
        with self.assertRaises(ValueError) as context:
            service.add_appointment(appointment_2)

        # assert exception confirmation
        self.assertEqual(str(context.exception), "Appointment ID must be unique.")

    # test method to delete an appointment
    def test_delete_appointment(self):

        # create new instance of AppointmentService
        service = AppointmentService()

        # create new appointment with parameters
        appointment = Appointment("1234567890", datetime.now() + timedelta(seconds=30),
                                  "Meeting")

        # add appointment to service
        service.add_appointment(appointment)

        # delete appointment using ID
        service.delete_appointment(appointment)

        # assert the number of appointments is equal to 0
        self.assertEqual(len(service.appointments), 0)

# run unittest framework
if __name__ == '__main__':
    unittest.main()








